<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Item Info</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
<div data-bs-theme="light"class="container">
    <div class="row" style="margin: 100px">
        <div class="">
            <p class="text-center h1 bg-info" style="padding:10px">All Item List</p>
            <a class="" href="/newitemform"><button class="btn btn-success" style="margin-bottom: 7px" >Add Item</button></a>

            
            <?php if(session('status')): ?>
                <div id="alert-mgs" class="alert alert-success"><?php echo e(session('status')); ?><button type="button" class="close float-end" data-dismiss="alert">X</button></div>
            <?php endif; ?>

            <table class="table table-bordered table-striped text-center">
                <tr class="">
                    <th class="" style="background-color:lightblue">Item Name</th>
                    <th  style="background-color:lightblue">Company Name</th>
                    <th class="" style="background-color:lightblue">Unit Price</th>
                    <th class="" style="background-color:lightblue">Options</th>
                </tr>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($item->item_name); ?></td>
                    <td><?php echo e($item->company_name); ?></td>
                    <td><?php echo e($item->unit_price); ?></td>

                    <td>
                        <a class="btn btn-secondary btn-sm disabled" href="">View</a>
                        <a class="btn btn-warning btn-sm" href="<?php echo e(route('update.item.info', $item->item_id)); ?>">Update</a>
                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('delete.item', $item->item_id)); ?>">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
</main>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script>
   $("document").ready(function()
    {
        $('#alert-mgs').delay(2000).fadeOut();
    },10000);
</script>
</body>
</html>


<?php /**PATH H:\BackUps\Laravel Projects\product-management\resources\views/iteminfo.blade.php ENDPATH**/ ?>