<h2>Welcome</h2>
<?php /**PATH H:\BackUps\Laravel Projects\product-management\resources\views/sample-Page.blade.php ENDPATH**/ ?>